# Visible Light Communication Positioning System with vehicle robot

Created By:
winghwu7-c@my.cityu.edu.hk
SID: 54882741

Source Code [Download](https://github.com/JackWu-CityU/JackWu-1-4-g8cf2194f4a7025f54ca8605b8154d6d3932f2323/archive/v1.0.zip "Download")

Simulator [here](https://www.tinkercad.com/embed/0lDDnGxLaKd "here")
or using iframe 
```
<iframe width="725" height="453" src="https://www.tinkercad.com/embed/0lDDnGxLaKd?editbtn=1" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>
```

3D model Object [here](https://www.tinkercad.com/embed/9JsM4fLSwcz "here")
```
<iframe width="725" height="453" src="https://www.tinkercad.com/embed/9JsM4fLSwcz?editbtn=1" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>
```
