<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" media="screen" href="./style/particles.js-master\demo\css/style.css">
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.6.1.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

    <link href="https://fonts.googleapis.com/css?family=Orbitron" rel="stylesheet">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style/buttonStyleCss.css" />

    <link href="style/background_font.css" rel="stylesheet" type="text/css">
    <link href="style/submitButton.css" rel="stylesheet" type="text/css">



    <style>
        body {
            font-family: 'Orbitron', "Microsoft Yahei", "微软雅黑", "华文细黑", sans-serif;
            background-color: rgba(0, 0, 0, 0);
            margin: 0px;
            padding: 0px;
            color: white;

        }

        #centerDiv {
            margin: 0px;
            position: absolute;
            top: 20%;
            padding: 0px;
            width: 100%;
            display: inline-block;

        }

        #headerDiv {
            top: 3%;
            right: 5%;
            position: absolute;
            font-size: 25px;
        }

        img {
            width: 100px;
            height: 100px;
        }

        div {

            display: inline-block;
        }

        div .innerDiv:hover {
            background-color: rgba(255, 255, 255, 0.9);
        }

        div .innerDiv {
            background-color: rgba(255, 255, 255, 0.7);
            color: black;
            z-index: 0;
            padding: 10px;
            box-shadow: 10px 10px 5px #888888;
            width: 300px;
            font-size: 20px;
            vertical-align: top;
            text-align: center;
            alignment-adjust: central;
            border: 1px solid black;
            border-color: black;
            margin: 20px;
        }

        h1 {
            color: white;
            font-size: 60px;
            -webkit-text-stroke-width: 1px;
            -webkit-text-stroke-color: gray;
        }

        .animated-button {
            z-index: 10;
        }

        #mainPage_header {
            position: absolute;


        }

        .disabled {
            pointer-events: none;
            cursor: default;
            opacity: 0.6;
        }

        .count-particles {
            display: none;
        }

        #stats {
            display: none;
        }

        #particles-js {
            position: absolute;

        }

        .modal-content {
            background-color: rgba(0, 0, 0, 0.7);
            height: 700px;
            width: 150%;
            color: white;



        }

        .modal-title {
            color: red;
            font-size: 300%;
            line-height: 400%;
            background-color: rgba(255, 255, 255, 0.2);

        }

        .title {
            text-align: center;
            line-height: 200%;
            background-image: url(../resource/image/blue_background.png);
            background-size: 100%;
            color: DodgerBlue;
            font-size: 200%;
            height: 20%;
            width: 100%;
        }
    </style>

    <script>
        $(document).ready(function() {
            $("#cloud").click(function() {
                var win = window.open(url, '_blank');
                win.focus();
            });
        });
    </script>

</head>

<body id="particles-js">
    <div id="headerDiv">
        <a href="/fyp/mainPage.php">Main Page</a>
    </div>
    <div id="centerDiv">
        <div style="width:auto;margin:15px">
            <!-- <h1>Azure Cloud Platform</h1> -->
            <h3>Azure Cloud Platform</h3>
        </div>
        <br>
        <div class="centerDiv" style="vertical-align: top;text-align:center;width:100%">
            <a href="https://fyp-vlcps-54882741.azureiotcentral.com/device-sets/6071636c-adb0-4e99-88f5-b4b7c209de94/configuration" target="_blank">
                <div class="innerDiv">
                    <img src="./img/iot.png"><br />
                    <a>IoT central</a>
                </div>
            </a>

            <a target="_blank" href="https://portal.azure.com/#blade/HubsExtension/Resources/resourceType/Microsoft.Storage%2FStorageAccounts">
                <div id="cloud" class="innerDiv">
                    <img src="https://img.icons8.com/color/260/azure-storage-blob.png"><br />
                    <a>Blob Storage</a>
                </div>
            </a>






        </div>

        <hr />


    </div>



    <script src="style\particles.js-master\particles.js"></script>
    <script src="style\particles.js-master\demo\js/app.js"></script>
    <script src="style\particles.js-master\demo\js/lib/stats.js"></script>
</body>

</html>