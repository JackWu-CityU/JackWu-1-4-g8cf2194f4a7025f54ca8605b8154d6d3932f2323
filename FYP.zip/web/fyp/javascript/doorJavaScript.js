    function test(){
        alert("running");
    }
	
	function openDoor(){
	document.getElementById('right').id = 'right_open';
	document.getElementById('left').id = 'left_open';
	}
	function closeDoor(){
	document.getElementById('right_open').id = 'right';
	document.getElementById('left_open').id = 'left';
	}
	function nextPage(url){
		closeDoor();
		var delay=5000; //5 second
		setTimeout(function() {
		  // similar behavior as an HTTP redirect
			window.location.replace(url);
		}, delay);
	}
	
