import RPi.GPIO as GPIO
from functools import wraps

def singleton(cls):
    instances = {}
    @wraps(cls)
    def getinstance(*args, **kw):
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]
    return getinstance

@singleton
class CarController:
    def __init__(self):
        self.pin = [31,33,35,37]
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(self.pin, GPIO.OUT)
        GPIO.setwarnings(False)
        for i in self.pin:
            print(i)
        GPIO.cleanup()

    def move_up(self):
        print("move_up")

    def move_down(self):
        print("move_down")

    def move_left(self):
        print("move_left")

    def move_right(self):
        print("move_right")

