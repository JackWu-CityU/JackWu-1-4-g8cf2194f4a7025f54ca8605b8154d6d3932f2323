from classDir.CarController import CarController
from websocket_server import WebsocketServer
import json

 # Called for every client connecting (after handshake)
def new_client(client, server):
         print("New client connected and was given id %d" % client['id'])
         #server.send_message_to_all("a new client...")
         server.send_message(client,"vehicle connected")
 
# Called for every client disconnecting
def client_left(client, server):
        print("Client(%d) disconnected" % client['id'])

# Called when a client sends a message
def message_received(client, server, message):
        if len(message) > 200:
                message = message[:200]+'..'
        print("Client(%d)_address%s said: %s" % (client['id'],client['address'], message))

        obj = None

        try:
            obj = json.loads(message)
            #print(obj)
        except:
            print("invalid JSON String")
            return

        if "move" in obj :
            checkMovement(obj["move"])
        
        server.send_message(client,'user id'+str(client['id'])+':'+message)

#customer function to hanle the user input
def checkMovement(direction):
    if direction == "up":
        car.move_up()
    elif direction == "down":
        car.move_down()
    elif direction == "left":
        car.move_left()
    elif direction == "right":
        car.move_right()
    elif direction == "stop":
        car.move_stop()

car = CarController()
PORT=9001
server = WebsocketServer(PORT,host="0.0.0.0")
server.set_fn_new_client(new_client)
server.set_fn_client_left(client_left)
server.set_fn_message_received(message_received)
server.run_forever()