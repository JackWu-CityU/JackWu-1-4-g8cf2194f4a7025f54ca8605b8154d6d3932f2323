import math

class City:
    def __init__(self, id, x, y):
        self.id = id
        self.x = int(x)
        self.y = int(y)
    
    def display(self):
        print("City "+str(self.id)+" x:"+str(self.x)+" y:"+str(self.y))

    @staticmethod
    def distance(c1, c2) -> float:
        d = math.sqrt(pow((c1.x - c2.x),2) + pow((c1.y - c2.y),2)) 
        return d