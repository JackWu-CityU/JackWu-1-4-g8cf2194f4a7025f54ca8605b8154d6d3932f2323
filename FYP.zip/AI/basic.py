from websocket_server import WebsocketServer
import json
import random
import csv


from classDir.City import City


def initPopulation(size, _cityArray) ->list:
    # init population
    population = []
    for i in range(size):
        gene = []
        for x in range(0, len(_cityArray)):
            gene.append(x)
        random.shuffle(gene)
        population.append(gene)
    return population


def initCity() -> list:
    xArray = [0.3642, 0.7185, 0.0986, 0.2954, 0.5951,
        0.6697, 0.4353, 0.2131, 0.3479, 0.4516]
    yArray = [0.7770, 0.8312, 0.5891, 0.9606, 0.4647,
        0.7657, 0.1709, 0.8349, 0.6984, 0.0488]
    # for i in range(0,20):
    #     xArray.append(random.random())
    #     yArray.append(random.random())

    cityArray = []

    for i in range(len(xArray)):
        c = City(i+1, xArray[i], yArray[i])
        cityArray.append(c)

    return cityArray


def totalDistance(populationArray, _cityArray) -> float:
    sum = 0.0
    for i in range(len(populationArray)-1):
        # print(str(populationArray[i])+":"+str(populationArray[i+1]))
        sum += City.distance(_cityArray[populationArray[i]],
                             _cityArray[populationArray[i+1]])
    return sum


def getFitnessArray(_populationPool, _cityArray) -> list:
    fitnessArray = []
    for x in _populationPool:
        sum = totalDistance(x, _cityArray)
        fitness = 1 / sum
        fitnessArray.append(fitness)
        # print("sum "+str(sum) + " fitness" + str(fitness))
    return fitnessArray


def selection(_fitnessArray, _populationPool) -> list:
    selectedArray = []

    # -- best gene save
    bestChromosome = _fitnessArray.index(max(_fitnessArray))
    selectedArray.append(_populationPool[bestChromosome])

    totalRange = sum(_fitnessArray)

    for i in range(len(_populationPool)-1):
        randomNum = random.uniform(0, totalRange)  # get random number
        for j in range(len(_populationPool)):  # check the number in what position
            if randomNum > _fitnessArray[j]:
                randomNum -= _fitnessArray[j]
            else:
                selectedArray.append(_populationPool[j])
                break

    return selectedArray


def crossover(_selectedArray) -> list:
    _crossoveredArray = []
    v1 = random.randint(0, len(_selectedArray[0])-1)
    v2 = random.randint(0, len(_selectedArray[0])-1)
    startPointer = min(v1, v2)
    endPointer = max(v1, v2)
    # print(str(startPointer)+" to "+str(endPointer))

    index = 0
    while index < len(_selectedArray):

        crossoverFlag = random.random() < crossoverRate
        if crossoverFlag == False:
            arrayC1 = list(_selectedArray[index])
            arrayC2 = list(_selectedArray[index+1])
            _crossoveredArray.append(arrayC1)
            _crossoveredArray.append(arrayC2)
            index += 2
            continue

        arrayC1 = [None] * len(_selectedArray[0])
        arrayC2 = [None] * len(_selectedArray[0])

        # keep parent gene
        pointer = startPointer
        while True:
            arrayC1[pointer] = _selectedArray[index][pointer]
            arrayC2[pointer] = _selectedArray[index+1][pointer]
            if pointer == endPointer:
                break
            else:
                pointer += 1
                pointer %= len(_selectedArray[0])

        # crossover parent gene
        pointerC1 = (endPointer+1) % len(_selectedArray[0])
        pointerC2 = (endPointer+1) % len(_selectedArray[0])
        offsetP1 = pointerC1
        offsetP2 = pointerC2

        while True:
            # parent 2 with child 1
            if _selectedArray[index+1][offsetP2] in arrayC1:
                offsetP2 = (offsetP2+1) % len(_selectedArray[0])
            else:
                arrayC1[pointerC1] = _selectedArray[index+1][offsetP2]
                pointerC1 += 1
                pointerC1 %= len(_selectedArray[0])

            # parent 1 with child 2
            if _selectedArray[index][offsetP1] in arrayC2:
                offsetP1 = (offsetP1+1) % len(_selectedArray[0])
            else:
                arrayC2[pointerC2] = _selectedArray[index][offsetP1]
                pointerC2 += 1
                pointerC2 %= len(_selectedArray[0])

            if pointerC1 == startPointer and pointerC2 == startPointer:
                break

        _crossoveredArray.append(arrayC1)
        _crossoveredArray.append(arrayC2)
        index += 2

    return _crossoveredArray


def mutation(crossoveredArray) -> list:
    _crossoveredArray = list(crossoveredArray)
    for i in range(0, len(_crossoveredArray)):
        for j in range(0, len(_crossoveredArray[i])):
            mutationFlag = (random.random() < mutationRate)
            # print(str(_crossoveredArray[i])+" : "+str(mutationFlag))
            if mutationFlag:
                num1 = j
                num2 = random.randint(0, len(_crossoveredArray[i])-1)
                temp = _crossoveredArray[i][num1]

                _crossoveredArray[i][num1] = _crossoveredArray[i][num2]
                _crossoveredArray[i][num2] = temp

    return _crossoveredArray

# init
cityArray = initCity()  # cityArray = []
mutationRate = 0.03
crossoverRate = 0.7
doXtime = 1
maxGeneration = 100000
populationSize = 100


def ga(cityArray, populationSize, server, client):

    generation = 0
    populationPool = initPopulation(
        populationSize, cityArray)  # population = []
    fitnessArray = getFitnessArray(
        populationPool, cityArray)  # fitnessArray = []

    csvResultArray = []
    print("in GA")
    for i in range(0, maxGeneration):
        # selection
        selectedArray = selection(fitnessArray, populationPool)

        # crossover
        crossoveredArray = crossover(selectedArray)

        # mutation
        mutationedArray = mutation(crossoveredArray)
            #   -remove one element
        mutationedArray.pop(random.randrange(len(mutationedArray)))
            #   -push the best element in previous generation
        bestChromosome = fitnessArray.index(max(fitnessArray))
        mutationedArray.append(populationPool[bestChromosome])

        fitnessArray = getFitnessArray(
            mutationedArray, cityArray)  # update fitness array
        populationPool = mutationedArray

        mean = sum(fitnessArray)/len(fitnessArray)
        maxFitness = max(fitnessArray)
        csvResultArray.append(maxFitness)

        print("gen "+str(generation)+" : " +
              str(round(maxFitness, 2)) + "-" + str(round(mean, 2)))
        jsonObj = {'generation': str(generation), "chromosome": str(
            populationPool[fitnessArray.index(max(fitnessArray))]), "fitness": str(maxFitness)}
        
        if generation%100 == 0:
            server.send_message(client, json.dumps(jsonObj))
        generation += 1

    print(str(populationPool[fitnessArray.index(
        max(fitnessArray))]) + "fitness="+str(max(fitnessArray)))


def new_client(client, server):
         print("New client connected and was given id %d" % client['id'])
         # server.send_message_to_all("a new client...")


# Called for every client disconnecting


def client_left(client, server):
        print("Client(%d) disconnected" % client['id'])

        

# Called when a client sends a message


def message_received(client, server, message):
        if len(message) > 200:
                message = message[:200]+'..'
        print("Client(%d)_address%s said: %s" %
              (client['id'], client['address'], message))

        obj = None

        try:
            obj = json.loads(message)
            print(obj)
            server.send_message(client, "JSON creived")
        except:
            print("invalid JSON String")
            server.send_message(client, "invalid JSON String")
            return


        xArray = obj['x']
        yArray = obj['y']
        cityArray = []

        for i in range(len(xArray)):
            c = City(i+1,xArray[i],yArray[i])
            cityArray.append(c)

        for i in range(doXtime):
            ga(cityArray,populationSize,server,client)


PORT=9002
server = WebsocketServer(PORT,host="0.0.0.0")
server.set_fn_new_client(new_client)
server.set_fn_client_left(client_left)
server.set_fn_message_received(message_received)
server.run_forever()  
        


